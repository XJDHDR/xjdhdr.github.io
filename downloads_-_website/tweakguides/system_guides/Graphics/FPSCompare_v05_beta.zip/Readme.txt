-------------------------------------------------------------
Downloaded from TweakGuides.com

Gamer's Graphics & Display Settings Guide:
http://www.tweakguides.com/Graphics_1.html
-------------------------------------------------------------


FPS Compare v0.5 BETA (C) Andreas Gustafsson

This is a small utility to help establish the answer to the old question
"Can you see the difference between XX and YY fps?"
This program displays 3D scenes running at different framrates.
The framerate indicator shows what the target framerate is, if you
use too high a framerate (say 100 fps if you have vsync on at 75Hz) the
numbers will turn red - that means that it is NOT running at desired framerate.

Instructions:
Press F1/F2 to switch between scene 1 and scene 2. Scene 1 with sharp contrasts
and fast movement often is more sensitive to low framerates than the landscape
in scene 2.
Press 'M' to switch between split-screen mode (where the left side of the
screen is running at one framerate and the right at another) and single-screen mode.
Press Left/Right to change which FPS to adjust (split-screen mode)
Press Space to toggle between framerates (single-screen mode)
Press Up/Down to adjust framerate (+/- 1 fps)
Press PgUp/PgDown to adjust framerate (+/- 10 fps)
Press 'H' to hide the framerate display.
Press 'R' to randomize (in split-screen it will randomly switch sides,
in single-screen it will randomly select on of the framerates).
Using 'H' and 'R' together is a very good way to do blind testing!
Press Esc to quit the program.

http://sdw.webhop.net
andreas.gustafsson@gmail.com