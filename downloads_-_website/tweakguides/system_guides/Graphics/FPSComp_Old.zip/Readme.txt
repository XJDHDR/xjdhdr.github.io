-------------------------------------------------------------
Downloaded from TweakGuides.com

Gamer's Graphics & Display Settings Guide:
http://www.tweakguides.com/Graphics_1.html
-------------------------------------------------------------


    -=[ FPS (frames per second) Compare v0.2 (C) 2000 Andreas Gustafsson ]=-

[ What is FPS Compare ]--------------------------------------------------------

This is an attempt at a small tool to settle the 'can you see the difference
between XX fps and YY fps'-argument that seem to arise now and then.
The idea is taken from an old demo by 3dfx, which showed one half of the
screen running at 30 fps and the other at 60 fps.
In this version you can select the fps for both sides yourself, using 'Q' and
'A' keys to increase and decrease the fps for the left side, and 'W' and 'S'
for the left side.
The reason that the program looks so boring and only runs in 640x480 is that I
wanted to make it simple, allowing users of not so powerful 3D cards run it.


[ System requirements ]--------------------------------------------------------

A moderately fast computer with a 3D card and a full OpenGL ICD should do it.
FPS Compare has been successfully tested on a Celeron 466@525 with GeForce DDR
and a Celeron 300@374 with TNT2U.
If the program doesn't work or have any bugs, consider that this is only a quick
hack thrown together in a couple of hours.


[ Notes on Vsync on/off etc. ]-------------------------------------------------

When comparing fps, one should always take into account whether vsync is on or
off. FPS Compare do not change these settings, so whether vsync is on or off is
based on what YOUR OpenGL settings are.
To get a good view of the exact difference between 60 and 30 fps, you should
set your 640x480 refresh rate at 60Hz and turn vsync on. But, running with vsync
off gives you the possibility to view more 'realistic' gaming performance
differences for example 42 vs. 56 fps
The reason that the deafult settings are 62 and 31 fps is that when running
with vsync on, you sometimes loose a frame when trying to run exactly 60 fps,
which can cause the framerate to drop considerably. So if you run with vsync on
and want to have an fps that is exactly the refreshrate, always set 0.5 or 1 fps
extra, for example if you want 75fps with a 75Hz refreshrate, set the fps at 76.
This does not apply when running with vsync off.


[ Credits ]--------------------------------------------------------------------

All programming by Andreas Gustafsson
Thanks to Aaron Hilton for the OpenGL-skeleton which this program to some
extent is based on. (check out http://oglchallenge.otri.net)
The texture is from a texturePack by Christopher Buechler.


[ Contact information ]--------------------------------------------------------

If you like this program, or have some new ideas, please contact me at:
sdw@lysator.liu.se

If you DON'T like this program, or just want to complain in general, write to:
who.cares@not.me ;)